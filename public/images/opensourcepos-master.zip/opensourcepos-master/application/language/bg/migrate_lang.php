<?php 

$lang["migrate_backup"] = "Be sure to back up your database before applying any database upgrades.";
$lang["migrate_failed"] = "Migration failed.";
$lang["migrate_info"] = "Click on Start Migration only if you are ready to apply all database changes and data upgrades to your database.";
$lang["migrate_start"] = "Start Migration ";
$lang["migrate_success"] = "Migrate successful.";
