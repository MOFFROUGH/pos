<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "البدء";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "اسم مستخدم/كلمة سر غير صحيح";
$lang["login_login"] = "دخول";
$lang["login_password"] = "كلمة السر";
$lang["login_username"] = "اسم المستخدم";
