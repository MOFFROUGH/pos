<?php 

$lang["migrate_backup"] = "";
$lang["migrate_failed"] = "Migration fehlgeschlagen.";
$lang["migrate_info"] = "";
$lang["migrate_start"] = "";
$lang["migrate_success"] = "";
