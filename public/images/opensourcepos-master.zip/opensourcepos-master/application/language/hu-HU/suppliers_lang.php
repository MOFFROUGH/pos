<?php 

$lang["suppliers_account_number"] = "Számla #";
$lang["suppliers_agency_name"] = "Ügynökség neve";
$lang["suppliers_cannot_be_deleted"] = "Nem lehet törölni a beszállítót, mert már van eladásuk.";
$lang["suppliers_company_name"] = "Cégnév";
$lang["suppliers_company_name_required"] = "Cégnév kötelező mező";
$lang["suppliers_confirm_delete"] = "Biztos, hogy törölni kívánja a kiválasztott beszállítókat?";
$lang["suppliers_confirm_restore"] = "";
$lang["suppliers_error_adding_updating"] = "Hiba beszállító hozzáadásánál/módosításánál";
$lang["suppliers_new"] = "Új beszállító";
$lang["suppliers_none_selected"] = "Nem választott ki beszállítót a törléshez";
$lang["suppliers_one_or_multiple"] = "beszállító(k)";
$lang["suppliers_successful_adding"] = "Sikeresen hozzáadott beszállítót";
$lang["suppliers_successful_deleted"] = "Sikeres törlés";
$lang["suppliers_successful_updating"] = "Sikeresen módosította a beszállítót";
$lang["suppliers_supplier"] = "Beszállító információ";
$lang["suppliers_supplier_id"] = "ID";
$lang["suppliers_update"] = "Bezsállító módosítása";
