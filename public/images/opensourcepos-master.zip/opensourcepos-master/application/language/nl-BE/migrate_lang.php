<?php 

$lang["migrate_backup"] = "Maak zeker een backup voor u database upgrades begint uit te voeren.";
$lang["migrate_failed"] = "";
$lang["migrate_info"] = "";
$lang["migrate_start"] = "";
$lang["migrate_success"] = "";
