<?php 

$lang["migrate_backup"] = "Sii sicuro di aver fatto un backup prima di applicare qualsiasi update al database.";
$lang["migrate_failed"] = "Migrazione fallita.";
$lang["migrate_info"] = "Premi su Migrazione Start solo se sei pronto ad applicare tutti i cambiamenti al database e gli upgrade ai dati del tuo database.";
$lang["migrate_start"] = "Start Migration ";
$lang["migrate_success"] = "Migrazione avvenuta con successo.";
