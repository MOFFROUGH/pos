<?php 

$lang["messages_first_name"] = "";
$lang["messages_last_name"] = "";
$lang["messages_message"] = "";
$lang["messages_message_placeholder"] = "";
$lang["messages_message_required"] = "";
$lang["messages_multiple_phones"] = "";
$lang["messages_phone"] = "";
$lang["messages_phone_number_required"] = "";
$lang["messages_phone_placeholder"] = "";
$lang["messages_sms_send"] = "";
$lang["messages_successfully_sent"] = "";
$lang["messages_unsuccessfully_sent"] = "";
