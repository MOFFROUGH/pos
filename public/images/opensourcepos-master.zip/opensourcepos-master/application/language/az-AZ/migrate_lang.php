<?php 

$lang["migrate_backup"] = "Hər hansı bir məlumat bazasını yeniləmədən öncə əmin olun ki məlumat bazası yaddaşda saxlanılmışdır.";
$lang["migrate_failed"] = "Yer dəyişmə uğursuz alındı";
$lang["migrate_info"] = "Yalnız hazır olduqdan sonra bütun məlumat bazasına dəyişikliklər və məlumat bazasını yeniləmək tətbiqi üçün Köçurməyə Başla düyməsinə basın.";
$lang["migrate_start"] = "Köçürməni Başla ";
$lang["migrate_success"] = "Köçurülmə Uğurlu Alındı";
