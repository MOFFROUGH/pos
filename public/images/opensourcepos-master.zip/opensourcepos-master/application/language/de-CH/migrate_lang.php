<?php 

$lang["migrate_backup"] = "";
$lang["migrate_failed"] = "";
$lang["migrate_info"] = "";
$lang["migrate_start"] = "";
$lang["migrate_success"] = "";
