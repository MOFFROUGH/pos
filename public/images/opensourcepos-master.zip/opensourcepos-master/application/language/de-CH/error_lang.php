<?php 

$lang["error_no_permission_module"] = "Sie haben nicht die Zugangsrechte für das gewählte Modul";
$lang["error_unknown"] = "Unbekannter Fehler";
